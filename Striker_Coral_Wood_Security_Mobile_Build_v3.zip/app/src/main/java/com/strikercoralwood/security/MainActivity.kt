package com.strikercoralwood.security

import android.Manifest
import android.app.*
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private val guards = arrayOf(
        "Pappu","Ashutosh","Rohit Kumar","Prem Singh","Shivam Kumar","Sukhapal",
        "Babbi","Harkesh","Shivkumar","Arjun","Vikash","Gajendra","Praveen",
        "Anugrha","Vineet","Vasudev","Arun","Sonu"
    )
    private val scans = mutableListOf<String>()
    private val incidents = mutableListOf<String>()
    private val attendance = mutableMapOf<String,String>()
    private lateinit var status: TextView

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val gps = result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        status.text = if (gps) "GPS permission granted" else "GPS permission not granted"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24,24,24,24)
        }

        val title = TextView(this).apply {
            text = "STRIKER CORAL WOOD SECURITY"
            textSize = 22f
            setTextColor(0xFF0B2D5C.toInt())
            setPadding(0,0,0,8)
        }
        root.addView(title)

        val site = TextView(this).apply {
            text = "SS Coral Wood & Almeria\nAdmins: Shambhu Dwivedi • Shubham Dwivedi\nSite strength: 37 Guards + 2 Ladies Guards"
            textSize = 15f
            setPadding(0,0,0,20)
        }
        root.addView(site)

        val guardSpinner = Spinner(this)
        guardSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, guards)
        root.addView(label("Select Guard"))
        root.addView(guardSpinner)

        val checkpointSpinner = Spinner(this)
        checkpointSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            (1..25).map { "Checkpoint ${it.toString().padStart(2,'0')}" })
        root.addView(label("QR Checkpoint"))
        root.addView(checkpointSpinner)

        val scanBtn = Button(this).apply {
            text = "SCAN / RECORD QR CHECKPOINT"
            setOnClickListener {
                val g = guardSpinner.selectedItem.toString()
                val cp = checkpointSpinner.selectedItem.toString()
                val t = now()
                scans.add("$t | $g | $cp")
                status.text = "✓ $cp recorded for $g at $t"
            }
        }
        root.addView(scanBtn)

        val incidentBtn = Button(this).apply {
            text = "🚨 INCIDENT / MISTAKE REPORT"
            setOnClickListener { showIncidentDialog(guardSpinner.selectedItem.toString()) }
        }
        root.addView(incidentBtn)

        val attendanceBtn = Button(this).apply {
            text = "ATTENDANCE"
            setOnClickListener { showAttendanceDialog() }
        }
        root.addView(attendanceBtn)

        val gpsBtn = Button(this).apply {
            text = "📍 ENABLE GPS / POST MONITORING"
            setOnClickListener { requestGps() }
        }
        root.addView(gpsBtn)

        val reportBtn = Button(this).apply {
            text = "DAILY REPORT"
            setOnClickListener { showReport() }
        }
        root.addView(reportBtn)

        status = TextView(this).apply {
            text = "Ready. 25 QR checkpoints configured."
            textSize = 14f
            setPadding(0,18,0,0)
        }
        root.addView(status)

        setContentView(root)
    }

    private fun label(s:String)=TextView(this).apply {
        text=s; textSize=13f; setPadding(0,10,0,2)
    }

    private fun requestGps() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.POST_NOTIFICATIONS
            ))
        } else {
            status.text = "GPS permission already granted. Production version will use background geofencing."
        }
    }

    private fun showIncidentDialog(guard:String) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(30,10,30,0) }
        val text=EditText(this).apply { hint="क्या गलती/घटना हुई?" }
        val photo=TextView(this).apply { text="📷 Photo: production version में mandatory camera capture होगा."; setPadding(0,15,0,10) }
        box.addView(text); box.addView(photo)
        AlertDialog.Builder(this)
            .setTitle("Incident Report — $guard")
            .setView(box)
            .setPositiveButton("SUBMIT") { _,_ ->
                val t=now()
                incidents.add("$t | $guard | ${text.text}")
                status.text="🚨 Incident submitted for supervisor review."
            }
            .setNegativeButton("CANCEL",null).show()
    }

    private fun showAttendanceDialog() {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        guards.forEach { g ->
            val cb=CheckBox(this).apply {
                text="$g — Present"
                isChecked=attendance[g]=="Present"
                setOnCheckedChangeListener { _,checked -> attendance[g]=if(checked)"Present" else "Absent" }
            }
            box.addView(cb)
        }
        ScrollView(this).apply { addView(box) }.also {
            AlertDialog.Builder(this).setTitle("Attendance").setView(it)
                .setPositiveButton("SAVE"){_,_->status.text="✓ Attendance saved."}
                .setNegativeButton("CANCEL",null).show()
        }
    }

    private fun showReport() {
        val present=attendance.values.count{it=="Present"}
        val report = "SS Coral Wood & Almeria\nDate: ${now()}\nSupervisors: Shambhu Dwivedi, Shubham Dwivedi\nCurrently added guards: ${guards.size}\nQR records: ${scans.size}\nIncidents: ${incidents.size}\nPresent marked: $present"
        AlertDialog.Builder(this).setTitle("Daily Report").setMessage(report)
            .setPositiveButton("OK",null).show()
    }

    private fun now():String = SimpleDateFormat("dd-MM-yyyy hh:mm a", Locale.getDefault()).format(Date())
}
