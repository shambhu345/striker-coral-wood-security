# Striker Coral Wood Security — Android Project

Site: SS Coral Wood & Almeria
Admins: Shambhu Dwivedi, Shubham Dwivedi
Current guards added: 18
QR checkpoints: 25

## Current starter functionality
- Guard selection using names supplied by the supervisor
- 25 checkpoint records
- Incident/mistake reporting starter flow
- Attendance
- GPS permission flow
- Daily report summary
- Supplied Striker logo included

## Important production work still required
1. Real QR camera scanner (ML Kit/ZXing)
2. Online Firebase/Supabase database
3. Supervisor accounts and secure login
4. Push notifications for missed rounds/incidents
5. Background GPS/geofencing with Android foreground service
6. Mandatory camera photo upload
7. Server-side daily reports
8. Add/edit remaining guards from admin panel
9. Anti-tamper checkpoint IDs and patrol scheduling

This package is source code, not a compiled APK. Build it with Android Studio/Gradle to produce the APK.
